function obtenerSaludo() {
    $.ajax({
      url: 'https://musicpro.bemtorres.win/api/v1/test/saludo',
      type: 'GET',
      success: function(response) {
        var message = response.message;
        alert(message); // Mostrar el saludo en una alerta
        // Aquí puedes realizar otras acciones con el saludo obtenido
      },
      error: function(error) {
        console.log('Error al obtener el saludo:', error);
      }
    });
  }